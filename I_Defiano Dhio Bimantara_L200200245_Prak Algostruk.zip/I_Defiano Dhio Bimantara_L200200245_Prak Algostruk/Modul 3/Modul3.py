##No 1
##def Matrix(data):
##    for x in data:
##        if type(x) is list:
##            if len(x) != len(data[0]):
##                return "Matrix tidak konsisten"
##                break
##            for i in x:
##                if type(i) is list:
##                    return "Matrix tidak konsisten"
##                    break
##        else:
##            return "Matrix tidak konsisten"
##            break
##        return [len(data), len(data[0])]
##
##A =  [[1, 2], [2, 3], [3, 3]]
##print("Hasil : ",Matrix(A))
##A =  [[1, 2], [2, 3], [3, 3, 4]]
##print("Hasil : ",Matrix(A))
##A =  [[1, 2], [2, 3], [3, [3, 4]]]
##print("Hasil : ",Matrix(A))
##A =  [1, 2, [2, 3], [3, [3, 3]]]
##print("Hasil : ",Matrix(A))
##print("Hasil : ",Matrix(A))
##print()
##print()
##
##def jumlah(a, b):
##    if Matrix(a) == Matrix(b) and Matrix(a) != "Matrix tidak konsisten" and Matrix(a) != "Matrix tidak konsisten":
##        hasil = []
##        for x in range(len(a)):
##            barisBaru = []
##            for j in range(len(a[x])):
##                print(a[x][j], b[x][j])
##                print(a[x][j] + b[x][j])
##                barisBaru.append(a[x][j] + b[x][j])
##            print("---Mengambil ukuran matrix---")
##            print(barisBaru)
##            hasil.append(barisBaru)
##        hasil1 = "\n Hasil penjumlahan dua matrix :\n"
##        for p in hasil:
##            hasil1 += str(p) + '\n'
##        hasil1 += "hasil dalam list : " + str(hasil)
##        return hasil1
##    elif Matrix(a) == "Matrix tidak konsisten" or Matrix(a) == "Matrix tidak konsisten":
##        return "cek lagi tipe data atau penulisan matrix kamu"
##    else:
##        return "cek lagi tipe data atau penulisan matrix kamu"
##
##b = [[5, 0],[2, 6]]
##c = [[1, 0],[4, 2]]
##print (jumlah(b, c))
##
##def kali(a, b):
##    if Matrix(a) == Matrix(b) and Matrix(a) != "Matrix tidak konsisten" and Matrix(a) != "Matrix tidak konsisten":
##        hasil = []
##        for x in range(0, len(a[0])):
##            barisBaru = []
##            for y in range(0, len (a[0])):
##                tot = 0
##                for z in range(0, len(a)):
##                    tot = tot + (a[x][z] * b[z][y])
##                barisBaru.append(tot)
##            hasil.append(barisBaru)
##
##        hasil1 = "\n Hasil perkalian dua matrix :\n"
##        for p in hasil:
##            hasil1 += str(p) + '\n'
##        hasil1 += "hasil dalam list : " + str(hasil)
##        return hasil1
##
##    elif Matrix(a) == "Matrix tidak konsisten" or Matrix(a) == "Matrix tidak konsisten":
##        return "cek lagi tipe data atau penulisan matrix kamu"
##    else:
##        return "cek lagi tipe data atau penulisan matrix kamu"
##print(kali(b, c))
##def determinan(matrix, mul):
##    width = len(matrix)
##    if width == 1:
##        return mul * matrix[0][0]
##    else:
##        masuk = -1
##        keluar = 0
##        for i in range(width):
##            m = []
##            for j in range(1, width):
##                buff = []
##                for k in range(width):
##                    if k != 1:
##                        buff.append(matrix[j][k])
##                m.append(buff)
##            masuk *= -1
##            keluar = keluar + mul * determinan(m, masuk * matrix[0][i])
##    return keluar
##
##A = [[-2, 2, -3], [-1, 1, 3], [2, 0, -1]]
##det = determinan(A, 1)
##print("\n Determinan matrix bujursangkar:" ,det)
                      
#No 2
def buatNol(m,n=0):
    if n==0:
        return [ [0 for j in range(m)] for i in range(m) ]
    else:
        return [ [0 for j in range(m)] for i in range(n) ]

def buatIdentitas(m):
    return [[1 if j==i else 0 for j in range(3)] for i in range(3)]

##No 3
##class Node:
##    def __init__(self,data):
##        self.data = data
##        self.next = None
##class Linkedlist:
##    def __init__(self):
##        self.head = None
##    def tambahDepan(self, dataBaru):
##        nodeBaru = Node(dataBaru)
##        nodeBaru.next = self.head
##        self.head = nodeBaru
##    def tambahAkhir(self, data):
##        if (self.head == None):
##            self.head = Node(data)
##        else:
##            curr = self.head
##            while (curr.next != None):
##                curr = curr.next
##    def tambah(self, data, posisi):
##        node = Node(data)
##        if not self.head:
##            self.head = node
##        elif posisi == 0:
##            node.next = self.head
##            self.head = node
##        else:
##             prev = None
##             curr = self.head
##             currPcc = 0
##             while(curPcc < posisi) and curr.next:
##                 prev = curr
##                 curr = curr.next
##                 currPcc += 1
##             prev.next = node
##             node.next = curr
##    def hapus(self, posisi):
##        if self.head == None:
##            return
##        hapus = self.head
##        if posisi == 0:
##            self.head = hapus.next
##            hapus = None
##            return
##        for i in range(posisi -1):
##            hapus = hapus.next
##            if hapus is None:
##                break
##            if hapus is None:
##                return
##            if hapus.next is None:
##                return
##            next = hapus.next.next
##            hapus.next = None
##            hapus.next = next
##    def cari(self, angka):
##        curr = self.head
##        while curr != None:
##            if curr.data == angka:
##                return True
##            curr = curr.next
##        return False
##    def lihatList(self):
##        curr = self.head
##        while curr is not None:
##            print(curr.data, end= ' ')
##            curr = curr.next
            
#No 4
class Node:
    def __init__(self, data= None, next=None, prev=None):
        self.data = data
        self.next = next
        self.prev = prev
class doublyLinkedlist:
    def __init__(self):
        self.head = None
        self.tail = None
        self.count = 0
    def tambahAkhir(self, data):
        new_item = Node(data, None, None)
        if self.head is None:
            self.head = new_item
            self.tail = self.head
        else:
            new_item.prev = self.tail
            self.tail.next = new_item
            self.tail = new_item
        self.count += 1
    def tambahAwal(self, data):
        new_node = Node(data)
        new_node.next = self.tail
        if self.head is not None:
            self.head.prev = new_node
        self.head = new_node
    def cetak(self):
        current = self.head
        while current:
            item_val = current.data
            current = current.next
            yield item_val
    def cetakBalik(self):
        current = self.balik()
        while current:
            item_val = current.data
            current = current.next
            yield item_val
    def cetakMaju(self):
        for node in self.cetakBalik():
            print(node)
    def balik(self):
        curr = self.head
        prev_node = None
        while curr:
            prev_node = curr.prev
            curr.prev = curr.next
            curr.next = prev_node
            curr = curr.prev
        return prev_node.prev
    def cetakMundur(self):
        for node in self.cetak():
            print(node)

a = doublyLinkedlist()
a.tambahAkhir(66)
a.tambahAkhir(22)
a.tambahAkhir(33)
a.tambahAkhir(44)
print("Mencetak semua isi Node dari depan : ")
a.cetakMundur()
print("Mencetak semua isi Node dari belakang : ")
a.cetakMaju()
print("Menambah node ke depan head : ")
a.tambahAwal(5)
a.cetakMundur()
            
             
