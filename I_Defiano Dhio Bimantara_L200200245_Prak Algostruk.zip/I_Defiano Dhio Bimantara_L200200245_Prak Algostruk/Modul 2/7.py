import LatOOP4
class MhsTIF(LatOOP4.Mahasiswa): 
    """Class MhsTIF yang dibangun dari class Mahasiswa"""
    def katakanPy(self):
        print("Python is cool.")


