class Member:
    def __init__(self, nama, alamat):
        self.nama = nama
        self.alamat = alamat
    def prin(self):
        print("Ketik")

class Mahasiswa(Member):
    maxIPK = 4.0
    def __init__(self,ipk):
        self.IPK = ipk
    def __str__(self):
        return "Ini adalah str"
