li=["list", "tuple", "dict"]
def hapus(x):
    for i in range(0, len(li)):
        if x == li[i]:
            print(li)
hapus("list")
print(li)