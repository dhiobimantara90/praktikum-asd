class Manusia(object):
    """ Class ’Manusia’ dengan inisiasi ’nama’ """
    keadaan = "lapar"
    def __init__(self,nama):
        self.nama = nama
    def ucapkanSalam(self):
        print("Salaam, namaku", self.nama)
    def makan(self, s):
        print("Saya baru saja makan", s)
        self.keadaan = "kenyang"
    def olahraga(self,k):
        print("Saya baru saja latihan", k)
        self.keadaan = "lapar"
    def mengalikanDenganDua(self,n):
        return n*2

## Kita menggunakannya dalam file yang sama.

class Mahasiswa(Manusia):
    """Class Mahasiswa yang dibangun dari class Manusia."""
    def __init__(self,nama,NIM,kota,us):
        """Metode inisiasi ini menutupi metode inisiasi di class Manusia."""
        self.nama = nama
        self.NIM = NIM
        self.kotaTinggal = kota
        self.uangSaku = us
    def __str__(self):
        s = self.nama + ", NIM " + str(self.NIM) \
            + ". Tinggal di " + self.kotaTinggal \
            + ". Uang saku Rp " + str(self.uangSaku) \
            + " tiap bulannya."
        return s
    def ambilNama(self):
        return self.nama
    def ambilNIM(self):
        return self.NIM
    def ambilUangSaku(self):
        return self.uangSaku
    def makan(self,s):
        """Metode ini menutupi metode ’makan’-nya class Manusia.
        Mahasiswa kalau makan sambil belajar."""
        print("Saya baru saja makan",s,"sambil belajar.")
        self.keadaan = "kenyang"

# ada kelanjutannya (lihat di "Soal-soal untuk Mahasiswa").
    def ambilKotaTinggal(self):
        print(self.kotaTinggal)
    def perbaruiKotaTinggal(self, kotaBaru):
        self.kotaTinggal = kotaBaru
    def tambahUang(self, uang):
        self.uangSaku += uang

##mhs = Mahasiswa("Dhio", "L20020045", "Madiun", 60000)
##mhs.perbaruiKotaTinggal("Surakarta")
##mhs.ambilKotaTinggal()
##mhs.tambahUang(20000)
##print(mhs.ambilUangSaku())
        
