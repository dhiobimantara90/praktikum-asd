class Pesan:
    def __init__(self, string1):
        self.teks = string1
    def cetak(self):
        print(self.teks)
    def cetakPakaiHurufKapital(self):
        print(str.upper(self.teks))
    def cetakPakaiHurufKecil(self):
        print(str.lower(self.teks))
    def jumKar(self):
        print(len(self.teks))
    def cetakJumlahKarakterKu(self):
        print("Kalimatku mempunyai",len(self.teks),"karakter")
    def perbarui(self, pembaruan):
        self.teks = pembaruan
