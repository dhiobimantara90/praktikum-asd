class Manusia(object):
    """ Class ’Manusia’ dengan inisiasi ’nama’ """
    keadaan = "lapar"
    def __init__(self,nama):
        self.nama = nama
    def ucapkanSalam(self):
        print("Salaam, namaku", self.nama)
    def makan(self, s):
        print("Saya baru saja makan", s)
        self.keadaan = "kenyang"
    def olahraga(self,k):
        print("Saya baru saja latihan", k)
        self.keadaan = "lapar"
    def mengalikanDenganDua(self,n):
        return n*2

## Kali ini melarikannya lewat file yang sama.
## Lewat python shell juga bisa.

class Mahasiswa(Manusia):
    """Class Mahasiswa yang dibangun dari class Manusia."""
    def __init__(self,nama,NIM,kota,us):
        """Metode inisiasi ini menutupi metode inisiasi di class Manusia."""
        self.nama = nama
        self.NIM = NIM
        self.kotaTinggal = kota
        self.uangSaku = us
        self.listKuliah = []
    def __str__(self):
        s = self.nama + ", NIM " + str(self.NIM) \
            + ". Tinggal di " + self.kotaTinggal \
            + ". Uang saku Rp " + str(self.uangSaku) \
            + " tiap bulannya."
        return s
    def ambilNama(self):
        return self.nama
    def ambilNIM(self):
        return self.NIM
    def ambilUangSaku(self):
        return self.uangSaku
    def makan(self,s):
        """Metode ini menutupi metode ’makan’-nya class Manusia.
        Mahasiswa kalau makan sambil belajar."""
        print("Saya baru saja makan",s,"sambil belajar.")
        self.keadaan = "kenyang"
    def ambilKuliah(self, matKul):
        self.listKuliah.append(matKul)

# ada kelanjutannya (lihat di "Soal-soal untuk Mahasiswa").
##mhs = Mahasiswa("Dhio", "L200200245", "Madiun", 60000)
##print(mhs)
##mhs.ambilKuliah("Matematika Diskrit")
##print(mhs.listKuliah)
##print(mhs.nama)

