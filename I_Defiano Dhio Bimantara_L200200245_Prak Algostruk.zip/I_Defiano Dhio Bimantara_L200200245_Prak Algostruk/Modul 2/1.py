class Pesan:
    def __init__(self, string1):
        self.teks = string1
    def cetak(self):
        print(self.teks)
    def cetakPakaiHurufKapital(self):
        print(str.upper(self.teks))
    def cetakPakaiHurufKecil(self):
        print(str.lower(self.teks))
    def jumKar(self):
        print(len(self.teks))
    def cetakJumlahKarakterKu(self):
        print("Kalimatku mempunyai",len(self.teks),"karakter")
    def perbarui(self, pembaruan):
        self.teks = pembaruan
    def apakahTerkandung(self, text):
        if text in self.teks:
            print(True)
        else:
            print(False)
    def hitungKonsonan(self):
        jmlKonsonan = 0
        self.teks.lower()
        vokal = ["a", "i", "u", "e", "o", " "]
        for i in self.teks:
            if i not in vokal:
                jmlKonsonan += 1
        print(jmlKonsonan)
    def hitungVokal(self):
        jmlVokal = 0
        self.teks.lower()
        vokal = ["a", "i", "u", "e", "o"]
        for i in self.teks:
            if i in vokal:
                jmlVokal += 1
        print(jmlVokal)

pesanku = Pesan("Ini adalah pesanku")
pesanku.hitungVokal()
pesanku.hitungKonsonan()
pesanku.apakahTerkandung("ni")