from codecs import namereplace_errors


class Manusia(object):
    """ Class ’Manusia’ dengan inisiasi ’nama’ """
    keadaan = "lapar"
    def __init__(self,nama):
        self.nama = nama
    def ucapkanSalam(self):
        print("Salaam, namaku", self.nama)
    def makan(self, s):
        print("Saya baru saja makan", s)
        self.keadaan = "kenyang"
    def olahraga(self,k):
        print("Saya baru saja latihan", k)
        self.keadaan = "lapar"
    def mengalikanDenganDua(self,n):
        return n*2

## Kali ini melarikannya lewat file yang sama.
## Lewat python shell juga bisa.

class SiswaSMA(Manusia):
    def __init__(self,nama,alamat,no_absen,kelas):
        self.nama = nama
        self.alamat = alamat
        self.no_absen = no_absen
        self.kelas = kelas
    def __str__(self):
        s = "Nama :", self.nama,"Alamat : ",self.alamat,"Kelas",self.kelas,"Nomor Absen :",self.no_absen
        return s
    def salamkpdBapakdanIbuGuru(self, waktu):
        if waktu == "pagi":
            print("Selamat pagi bu guruuuuu")
        elif waktu == "siang":
            print("Selamat siang bu guruuu")
        elif waktu == "sore":
            print("Selamat sore bu guruuu")
