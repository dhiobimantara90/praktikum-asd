class Manusia(object):
    """ Class ’Manusia’ dengan inisiasi ’nama’ """
    keadaan = "lapar"
    def __init__(self,nama):
        self.nama = nama
    def ucapkanSalam(self):
        print("Salaam, namaku", self.nama)
    def makan(self, s):
        print("Saya baru saja makan", s)
        self.keadaan = "kenyang"
    def olahraga(self,k):
        print("Saya baru saja latihan", k)
        self.keadaan = "lapar"
    def mengalikanDenganDua(self,n):
        return n*2

## Kita menggunakannya dalam file yang sama.

class Mahasiswa(Manusia):
    """Class Mahasiswa yang dibangun dari class Manusia."""
    def __init__(self):
        """Metode inisiasi ini menutupi metode inisiasi di class Manusia."""
        self.masukkanData()
    def __str__(self):
        s = self.nama + ", NIM " + str(self.NIM) \
            + ". Tinggal di " + self.kotaTinggal \
            + ". Uang saku Rp " + str(self.uangSaku) \
            + " tiap bulannya."
        return s
    def ambilNama(self):
        return self.nama
    def ambilNIM(self):
        return self.NIM
    def ambilUangSaku(self):
        return self.uangSaku
    def makan(self,s):
        """Metode ini menutupi metode ’makan’-nya class Manusia.
        Mahasiswa kalau makan sambil belajar."""
        print("Saya baru saja makan",s,"sambil belajar.")
        self.keadaan = "kenyang"
        
    def masukkanData(self):
        self.nama = input("Masukkan Nama Lengkap \t  => ")
        self.NIM = input("Masukkan NIM \t\t  => ")
        self.kotaTinggal = input("Masukkan nama kotamu \t  => ")
        self.uangSaku = int(input("Masukkan Total Uang Saku  => "))

mhs3 = Mahasiswa()
print(mhs3)
