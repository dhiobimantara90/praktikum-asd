#Modul 7
#Defiano Dhio Bimantara
#Tugas
#Soal no 1
##import re
##
##f = open ("Indonesia.txt", "r")
##s = f.read()
##f.close()
##pola = r'me\w+'
##menampilkan = re.findall(pola,s)
##print(menampilkan)

##Soal no 2
##import re
##
##f = open ("Indonesia.txt", "r")
##s = f.read()
##f.close()
##pola = r'di\w+'
##menampilkan = re.findall(pola,s)
##print(menampilkan)

#nomor 3
import re

f = open('Indonesia.txt','r',encoding='latin1')

teks = f.read()
f.close()
p = r'di \w+'
hasil = re.findall(p, teks)

print(hasil)


##Soal no 4
##import re
##
##f = open ("KEI.html", "r", encoding='latin1')
##s = f.read()
##f.close()
##pola = r'">([\w+]+)</a></td>\n<td>([0-9.]+)</td>\n<td>([0-9.]+)</td>\n<td>([0-9.]+)</td>\n<td>([0-9.]+)</td>\n<td>([0-9.]+)</td>\n<td>([0-9.]+)</td>\n<td>'
##cocok = re.findall(pola, s)
##baru = []
##for i in cocok:
##    a = (i[0], float(i[4]))
##    baru.append(a)
##print(baru)

#Latihan
##import re
##
##s = 'sebuah contoh kata:teh!!'
##cocok = re.findall(r'kata:\w\w\w', s)
####Pernyaraan-IF sesudah findall() akan memeriksa apakah pencarian berhasil:
##if cocok:
##    print('menemukan', cocok) ## 'menemukan [kata:teh]
##else:
##    print('tidak menemukan')

##cocok = re.findall(r'eee', 'teeeh') #=> cocok == ['eee']
##cocok = re.findall(r'ehs', 'teeeh') #=> cocok == []
##cocok = re.findall(r'..h', 'teeeh') #=> cocok == ['eeh']
##cocok = re.findall(r'\d\d\d', 't123h di 2019 bulan 02') #=> cocok == ['123', '201']
##cocok = re.findall(r'\w\w\w', '@@*bc#def*tghh!!') #=> cocok ['def', 'tgh']

##import re
#### e+ = satu atau lebih e, sebanyak-banyaknya.
##cocok = re.findall(r'te+', 'ghdteeeh') #=> cocok ['teee']
##
#### Menemukan solusi yang paling kiri, dan dari situ mendonrong si tanda '+'
#### sejauh-jauhnya(ingat 'paling kiri dan paling besar')
#### Pada contoh ini, perhatikan bahwa pencarian menemukan dua pola yang tepat.
##cocok = re.findall(r'e+', 'teeheeee') #=> cocok ['ee', 'eeee']
##
#### \s* = nol atau lebih karakter putih (spasi, tab, dsb.)
#### Di sini mencari 3 angka, kemungkinan di pisahkan oleh spasi/tab.
##polanya = r'\d\s*\d\s*\d'
##cocok = re.findall(polanya, 'xx1 2 3xx')    #=> cocok ['1 2    3']
##cocok = re.findall(polanya, 'xx12 3xx')     #=> cocok ['12  3']
##cocok = re.findall(polanya, 'xx123xx')      #=> cocok ['123']
##
#### ^ -> cocok dengan awal string, jadi ini tidak menemukan:
##cocok = re.findall(r'^k\w+', 'mejakursi')   #=> tidak ketemu, cocok []
#### tapi tanpa^ dia berhasil
##cocok = re.findall(r'k[\w\s]+', 'mejakursi tamu saya')
##if cocok:
##    print('menemukan', cocok) ## 'menemukan [kata:teh]
##else:
##    print('tidak menemukan')
##cocok = re.findall(r'\w+@\w+', s)
##Latihan 7.3
##import re
##s = 'Alamatku adalah dita-b@google.com mas'
##cocok = re.findall(r'\w+@\w+', s)
##print(cocok[0])         ## =>   'b@google

##Latihan 7.3.2
##import re
##s = 'Alamatku adalah dita-b@google.com mas'
##cocok = re.findall(r'[\w.-]+@[\w.-]+', s)
##print(cocok[0])         ## => 'dita-b@google.com'

##Latihan 7.4
##import re
##s = 'Alamatku adalah dita-b@google.com mas'
##cocok = re.findall(r'([\w.-]+)@([\w.-]+)', s) ## perhatikan posisi () di polanya
####print (cocok )  ## adalah [('dita-b', 'google.com')]
#### Bisa kita pilah satu persatu seperti ini
####print (cocok[0] [0])  ## 'dita-b'
##print (cocok[0] [1])    ## 'google.com'

#latihan 7.4 lanjutan
##import re
#### kita punya banyak alamat email
##s = 'Alamatku sri@google.com serta joko@abc.com serta joko@abc.com ok bro. atau don@email.com'
##
#### Di sini re.findall() mengembalikan sebuah list beranggotakan string alamat
##pola = r'[\w\.-]+@[\w\.-]+'
##e = re.findall(pola, s)
##print(e)

##=>ArithmeticError e akan berisi ['sri@google,com', 'joko@abc.com', 'don@email.com']
##print(cocok[0])
## Pernyaraan-IF sesudah findall() akan memeriksa apakah pencarian berhasil:
##if cocok:
##    print('menemukan', cocok) ## 'menemukan [kata:teh]
##else:
##    print('tidak menemukan')

#Latihan 7.5
##import re
##pola = r'([\w\.-]+)@([\w\.-]+)'
##e = re.findall(pola, s)
####print(e)    ##==> sekarang bagaimana hasilnya?
#### Atau kita cetak satu per satu:
##for tup in e:
##    print('user', tup[0], 'dengan host:', tup[1])

#Latihan 7.4.1
##import re
##f = open('test.txt', 'r', encoding='latin1') ##membuka file.
##teks = f.read()
##f.close()
##p = r'sebuah pola'      # ini polanya
#### memberikan seluruhnya ke findall()
#### dia mengembalikan list beranggotakan string yang cocok
##strings = re.findall(p, teks)

##Latihan 7.2
##import re
#### Dua baris ini mencari pola 'eee' di string 'teeeh'.
#### Seluruh pola harus cocok, tapi itu bisa muncul di mana saja.
#### Jika berhasil, \texttt{cocok} adalah daftar semua teks yang cocok.
##cocok = re.findall(r'eee', 'teeeh') #=> cocok == ['eee']
##cocok = re.findall(r'ehs', 'teeeh') #=> cocok == []
##
#### . = semua karakter kecuali \n
##cocok = re.findall(r'..h', 'teeeh') #=> cocok == ['eeh']
###### \d = karakter angka, \w = karakter huruf atau angka
##cocok = re.findall(r'\d\d\d', 't123h di 2019 bulan 02') #=> cocok == ['123', '201']
##cocok = re.findall(r'\w\w\w', '@@*bc#def*tghh!!') #=> cocok ['def', 'tgh']
##if cocok:
##    print('menemukan', cocok) ## 'menemukan [kata:teh]
##else:
##    print('tidak menemukan')
