#Nomor 1 Defiano Dhio Bimantara
##def cetakSiku(x):
##    for i in range (x+1):
##        print (i * "*")

##def gambarPersegiEmpat(x,y):
##    for i in range(x):
##        if i == 0 or i == x-1:
##            print("@" * y)
##        else:
##            print("@"+" "*(y-2)+"@")
##

##def jumlahHurufKonsonan(hrf):
##    konsonan = 'bcdfghjklmnpqrstvwxyzBCDEFGHIJKLMNOPQRSTUVWXYZ'
##    b = 0
##    hasil = 0
##    for i in hrf:
##        if i in konsonan:
##             b+=len(i)
##        else:
##            b+= 0
##    hasil = len(hrf), b
##    return hasil

##def rerata(b):
##    jumlah = 0
##    for i in range(len(b)):
##        jumlah += b[i]
##    jumlah = jumlah/len(b)
##    return jumlah

##from math import sqrt as sq
##def apakahPrima(n):
##    n = int(n)
##    assert n>=0
##    primaKecil = [2,3,5,7,11]
##    bukanPrKecil = [0,1,4,6,8,9,10]
##    if n in primaKecil:
##        return True
##    elif n in bukanPrKecil:
##        return False
##    else:
##        for i in range(2,int(sq(n))+1):
##            if n%i==0:
##                return False
##        return True

##def bilanganPrima(n):
##    for i in range(2,n):
##        prima = True
##        for J in range(2,i):
##            if(i%J==0):
##                prima=False
##            if(prima):
##                print (i)

##def faktorPrima(x):
##    bilanganList = []
##    loop = 2
##    while loop <= x:
##        if x % loop == 0:
##            x /= loop
##            bilanganList.append(loop)
##        else:
##            loop += 1
##    return bilanganList

##def apakahTerkandung(a,b):
##    x = True
##    for i in range(len(b)):
##        if a in b:
##            x = True
##        else:
##            x = False
##    return x

##def kelipatan(x):
##    for i in range(x) :
##        if (i<=0):
##            pass
##        elif(i%3==0 and i%5==0):
##            print('Python UMS')
##        elif(i%3==0):
##            print('Python')
##        elif(i%5==0):
##            print('UMS')
##        else:
##            print (i)

##from math import sqrt as akar
##def selesaikanABC(a,b,c):
##    a = float(a) #mengubah jenis integer menjadi float
##    b = float(b)
##    c = float(c)
##    D = b**2 - 4*a*c
##    if D <= -1:
##        print("Determinan negatif. Persamaan tidak mempunyai akar real.")
##    else:
##        x1 = (-b + akar(D))/(2*a)
##        x2 = (-b - akar(D))/(2*a)
##        hasil = (x1,x2) #tuple yang terdiri dari dua elemen
##        return hasil

##def apakahKabisat(tahun):
##    if tahun % 4 == 0 and tahun % 100 != 0 or tahun % 400 == 0:
##        return True
##    else:
##        return False

##import random
##def tebakAngka(jarak):
##    chance = 1
##    print("Saya menyimpan angka bulat antara 1 sampai 100. Coba tebak.\nKamu hanya memiliki 6 kesempatan, semangat!")
##    pick = random.randint(1, jarak)
##    while chance <=6:
##        tebakan = int(input("Masukkan tebakan ke-"+str(chance)+" :>"))
##        if tebakan == pick:
##            print("Ya. Anda Benar")
##            break
##        elif tebakan < pick:
##            print("Itu terlalu kecil. Coba lagi")
##        elif tebakan > pick:
##            print("Itu terlalu besar. Coba lagi")
##        chance += 1

##angka = {1:"satu" , 2:"dua" , 3:"tiga" , 4:"empat" , 5:"lima" , 6:"enam" , 7:"tujuh" , 8:"delapan" , 9:"sembilan"}
##
##b = "puluh"
##c = "ratus"
##d = "puluh"
##e = "ribu"
##f = "milyar"
##g = "triliun"
##
##def katakan(x):
##    y = str(x)
##    n = len(y)
##    if n <= 3:
##        if n == 1:
##            if y == "0":
##                return ""
##            else:
##                return angka[int(y)]
##        elif n == 2:
##            if y[0] == "1":
##                if y[1] == "1":
##                    return "sebelas"
##            elif y[0] == "0":
##                x = y[1]
##                return katakan(x)
##            elif y[1] == "0":
##                return "sepuluh"
##            else:
##                return angka[int(y[1])]+ "belas"
##        elif y[0] == "0":
##            x = y[1]
##            return katakan[x]
##        else:
##            x = y[1]
##            return angka[int(y[0])]+ b + katakan(x)
##    else:
##        if y[0] == "1":
##            x = y[1:]
##            return "seratus " + katakan(x)
##        elif y[0] == "0":
##            x = y[1:]
##            return katakan(x)
##        else:
##            x = y[1:]
##            return angka[int(y[0])]+ c + katakan(x)
##        elif 3 < n <= 6:
##            p = y[-3:]
##            q = y[:-3]
##            if q == "1":
##                return "seribu " +katakan(p)
##            elif q == "000":
##                return katakan(p)
##            else:
##                return katakan(q) + d + katakan(p)
##        elif 6 < n <=9:
##            r = y[-6:]
##            s = y[:-6]
##            return katakan(s) + e + katakan(r)
##        elif 9 < n <=12:
##            r = y[-12:]
##            s = y[:-12]
##            return katakan(u) + f + katakan(t)
##        else:
##            v = y[-12:]
##            w = y[:-12]
##            return katakan(w) + g + katakan(v)
            
def formatRupiah(bilangan):
    y = str(bilangan)
    if len(y) <= 3 :
        return 'rp ' + y
    else:
        p = y[-3:]
        q = y[:-3]
        return formatRupiah(q) + '.' + p
    print ('Rp ' + formatRupiah(q) + '.' + P)

angka = {1:"satu " , 2:"dua " , 3:"tiga " , 4:"empat " , 5:"lima " , 6:"enam " , 7:"tujuh " , 8:"delapan " , 9:"sembilan "}

b = "puluh "
c = "ratus "
d = "ribu "
e = "juta "
f = "milyar "
g = "triliun "

def katakan(x):
    y = str(x)
    n = len(y)
    if n <= 3:
        if n == 1:
            if y == "0":
                return ""
            else:
                return angka[int(y)]
        elif n == 2:
            if y[0] == "1":
                if y[1] == "1":
                    return "sebelas"
                elif y[0] == "0":
                    x = y[1]
                    return katakan(x)
                elif y[1] == "0":
                    return "sepuluh"
                else:
                    return angka[int(y[1])]+ "belas"
            elif y[0] == "0":
                x = y[1]
                return katakan(x)
            else:
                x = y[1]
                return angka[int(y[0])]+ b + katakan(x)
        else:
            if y[0] == "1":
                x = y[1:]
                return "seratus " + katakan(x)
            elif y[0] == "0":
                x = y[1:]
                return katakan(x)
            else:
                x = y[1:]
                return angka[int(y[0])]+ c + katakan(x)
    elif 3 < n <= 6:
        p = y[-3:]
        q = y[:-3]
        if q == "1":
            return  "seribu " + katakan(p)
        elif q == "000":
            return katakan(p)
        else:
            return katakan(q) + d + katakan(p)
    elif 6 < n <=9:
        r = y[-6:]
        s = y[:-6]
        return katakan(s) + e + katakan(r)
    elif 9 < n <=12:
        t = y[-9:]
        u = y[:-9]
        return katakan(u) + f + katakan(t)
    else:
        v = y[-12:]
        w = y[:-12]
        return katakan(w) + g + katakan(v)
    
